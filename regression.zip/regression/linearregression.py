import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
from scipy.stats import linregress

#from scipy import linregress
# Read data
file_path = r"C:\Users\Sandeep Maheshwari\Desktop\Salary_Data.csv"
df = pd.read_csv(file_path)
# print(df)

# Data preprocessing
# Display first few rows of the dataset
print(df.head())

# Check for missing values
print(df.isnull().sum())

# # Drop rows with missing values, if any
df.dropna(inplace=True)

# # Extracting variables
X = df.drop(columns='Salary',axis=1)  # Make sure X is a 2D array
y = df['Salary']


slope, intercept, _, _, _ = linregress(X.squeeze(), y)

# Plotting graph to check which model we can use
plt.scatter(X, y, color='blue', label='Data points')  # Scatter plot
plt.plot(X, slope * X + intercept, color='red', label='Regression line')  # Straight line chart
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.title('Salary vs. Years of Experience')
plt.legend()
plt.show()

# Splitting the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=30)

# Creating a linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# # Making predictions on the testing data
y_pred = model.predict(X_test)
# print("Predicted values:", y_pred)

# # Evaluating the model
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("Mean Absolute Error:", mae)
print("R-squared:", r2)

#Plotting actual vs predicted values
plt.scatter(X_test,y_test,color='blue')
plt.plot(X_test,model.predict(X_test),color='red')
plt.title('Actual vs Predicted')
plt.xlabel('Years')
plt.ylabel('salary')
plt.show()


# Plotting the regression line with the data points
plt.scatter(X,y, color='blue', label='Data points')
plt.plot(X,model.predict(X), color='red', label='Regression line')
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.title('Salary vs. Years of Experience')
plt.legend()
plt.show()

#manually predict values
y_pred = model.predict([[3]])
print("Predicted values:", y_pred)