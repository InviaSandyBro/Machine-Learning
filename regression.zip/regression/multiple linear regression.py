import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error,r2_score
import matplotlib.pyplot as plt
# Read the data from a CSV file
df = pd.read_csv(r"C:\Users\Sandeep Maheshwari\Desktop\50_Startups.csv")
print(df)
# Assuming your dataset has columns 'R&D Spend', 'Administration', 'Marketing Spend', and 'Profit'
X = df[['R&D Spend', 'Administration', 'Marketing Spend']]
y = df['Profit']


# plt.figure(figsize=(15, 5))

# # Plotting R&D Spend vs Profit
# plt.subplot(1, 3, 1)
# plt.scatter(df['R&D Spend'], df['Profit'], color='blue')
# plt.title('R&D Spend vs Profit')
# plt.xlabel('R&D Spend')
# plt.ylabel('Profit')

# # Plotting Administration vs Profit
# plt.subplot(1, 3, 2)
# plt.scatter(df['Administration'], df['Profit'], color='green')
# plt.title('Administration vs Profit')
# plt.xlabel('Administration')
# plt.ylabel('Profit')

# # Plotting Marketing Spend vs Profit
# plt.subplot(1, 3, 3)
# plt.scatter(df['Marketing Spend'], df['Profit'], color='red')
# plt.title('Marketing Spend vs Profit')
# plt.xlabel('Marketing Spend')
# plt.ylabel('Profit')

# plt.tight_layout()
# plt.show()

# # Splitting the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

# # Creating a linear regression model
model = LinearRegression()

# # Training the model on the training data
model.fit(X_train, y_train)

# # Making predictions on the testing data
y_pred = model.predict(X_test)

# # Evaluating the model
mse = mean_squared_error(y_test, y_pred)
print("Mean Squared Error:", mse)
r2=r2_score(y_test,y_pred)
print(r2)

# #Plotting actual vs predicted values
# plt.scatter(y_test, y_pred, color='blue')
# plt.plot(y_test, y_test, color='red')  # Plotting the perfect prediction line
# plt.title('Actual vs Predicted')
# plt.xlabel('Actual')
# plt.ylabel('Predicted')
# plt.show()

# manually predict the data
y_pred = model.predict([[22177.74,154806.14,28334.72]])
print("Predicted Profit values:", y_pred)